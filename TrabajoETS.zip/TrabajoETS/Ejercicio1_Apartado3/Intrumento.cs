﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado3
{
    public abstract class Intrumento
    {
        public Panel Panel
        {
            get => default;
            set
            {
            }
        }

        public CuerpoSolido CuerpoSolido
        {
            get => default;
            set
            {
            }
        }

        public void TratarInformacion()
        {
            throw new System.NotImplementedException();
        }

        public void Actualizar()
        {
            throw new System.NotImplementedException();
        }
    }
}