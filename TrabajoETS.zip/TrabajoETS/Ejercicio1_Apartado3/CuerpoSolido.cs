﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado3
{
    public class CuerpoSolido
    {
        private string imagen
        {
            get => default;
            set
            {
            }
        }

        private string direccion
        {
            get => default;
            set
            {
            }
        }

        private string posicion
        {
            get => default;
            set
            {
            }
        }

        private decimal velocidad
        {
            get => default;
            set
            {
            }
        }

        public void Notificar()
        {
            throw new System.NotImplementedException();
        }

        public void PermitirSub()
        {
            throw new System.NotImplementedException();
        }

        public void PermitirBaja()
        {
            throw new System.NotImplementedException();
        }
    }
}