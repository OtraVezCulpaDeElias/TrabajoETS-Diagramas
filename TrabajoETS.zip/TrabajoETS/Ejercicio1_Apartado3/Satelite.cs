﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado3
{
    public class Satelite : CuerpoSolido
    {

        public void Aumentar()
        {
            throw new System.NotImplementedException();
        }

        public void Disminuir()
        {
            throw new System.NotImplementedException();
        }

        public void GirarIzquierda()
        {
            throw new System.NotImplementedException();
        }

        public void GirarDerecha()
        {
            throw new System.NotImplementedException();
        }

        public void Apagar()
        {
            throw new System.NotImplementedException();
        }
    }
}