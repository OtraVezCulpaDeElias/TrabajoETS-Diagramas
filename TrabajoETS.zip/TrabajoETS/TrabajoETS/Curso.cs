﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrabajoETS
{
    public class Curso
    {
        public void Matricula()
        {
            throw new System.NotImplementedException();
        }

        public void Desmatricular()
        {
            throw new System.NotImplementedException();
        }
    }
}