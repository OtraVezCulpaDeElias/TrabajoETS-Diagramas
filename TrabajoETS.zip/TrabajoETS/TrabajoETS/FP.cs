﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrabajoETS
{
    public class FP : Alumno
    {
        private string nombrePadre
        {
            get => default;
            set
            {
            }
        }

        private string nombreMadre
        {
            get => default;
            set
            {
            }
        }
    }
}