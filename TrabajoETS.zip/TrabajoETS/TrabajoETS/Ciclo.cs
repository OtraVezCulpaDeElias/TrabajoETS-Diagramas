﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrabajoETS
{
    public class Ciclo : Alumno
    {
        private string grado
        {
            get => default;
            set
            {
            }
        }

        private string curso
        {
            get => default;
            set
            {
            }
        }

        private string modalidad
        {
            get => default;
            set
            {
            }
        }
    }
}