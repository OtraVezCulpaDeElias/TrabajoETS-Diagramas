﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrabajoETS
{
    public class Persona
    {
        private string nombre
        {
            get => default;
            set
            {
            }
        }

        private string apellidos
        {
            get => default;
            set
            {
            }
        }

        private System.DateTime fechaNacimiento
        {
            get => default;
            set
            {
            }
        }

        public Instituto Instituto
        {
            get => default;
            set
            {
            }
        }
    }
}