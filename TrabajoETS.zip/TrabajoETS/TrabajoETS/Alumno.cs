﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrabajoETS
{
    public class Alumno : Persona
    {
        private System.Collections.Generic.List<decimal> notas
        {
            get => default;
            set
            {
            }
        }

        public Curso Curso
        {
            get => default;
            set
            {
            }
        }
    }
}