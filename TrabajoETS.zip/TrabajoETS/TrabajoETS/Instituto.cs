﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrabajoETS
{
    public class Instituto
    {
        private System.Collections.Generic.List<Alumno> Alumnos
        {
            get => default;
            set
            {
            }
        }

        private System.Collections.Generic.List<Profesor> Profesores
        {
            get => default;
            set
            {
            }
        }

        public System.Collections.Generic.List<Alumno> ContarAlumnos()
        {
            throw new System.NotImplementedException();
        }

        public System.Collections.Generic.List<Profesor> ContarProfesores()
        {
            throw new System.NotImplementedException();
        }
    }
}