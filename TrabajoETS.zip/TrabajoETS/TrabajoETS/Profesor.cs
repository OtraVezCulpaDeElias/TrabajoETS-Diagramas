﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrabajoETS
{
    public class Profesor : Persona
    {
        private string asignatura
        {
            get => default;
            set
            {
            }
        }

        public Curso Curso
        {
            get => default;
            set
            {
            }
        }
    }
}