﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    class Order
    {
        private List<Product> Products { get; set; }
        private DateTime DateTime { get; set; }

        internal CoffeShop CoffeShop
        {
            get => default;
            set
            {
            }
        }

        public Order(List<Product> products)
        {
            SetProducts(products);
            SetDateTime();
        }

        public void SetProducts(List<Product> products) { Products = products; }
        public List<Product> GetProducts() { return Products; }

        public void SetDateTime() { DateTime = DateTime.Now; }
        public DateTime GetDateTime() { return DateTime; }

        public static Order MakeOrder(List<Product> products)
        {
            List<Product> order = new List<Product>();
            int option;

            do
            {
                Console.Clear();
                Console.WriteLine("Escoge un producto de entre los siguientes: \n");
                Menu.ShowProducts(products);
                Console.WriteLine();
                if (order.Count != 0)
                {
                    Console.WriteLine("Este es tu pedido hasta el momento");
                    Menu.ShowProducts(order);
                    Console.WriteLine();
                }
                while (!Int32.TryParse(Console.ReadLine(), out option) || option < 0 || option > products.Count + 1)
                    Console.WriteLine("Esa opción no se encuentra en el menú");
                if (option != 0)
                    order.Add(products[option - 1]);
            } while (option != 0);

            Console.WriteLine("Pulse cualquier tecla para volver al menú...");
            return new Order(order);
        }
    }
}
