﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    class Menu
    {
        public static void ShowMenu()
        {
            Console.WriteLine("------------------------------------");
            Console.WriteLine("-               Menú               -");
            Console.WriteLine("------------------------------------");
            Console.WriteLine("-         Elige una opción         -");
            Console.WriteLine("------------------------------------");
            Console.WriteLine("- 0 : Salir del programa           -");
            Console.WriteLine("- 1 : Anotar pedido                -");
            Console.WriteLine("- 2 : Completar pedido             -");
            Console.WriteLine("- 3 : Hacer caja                   -");
            Console.WriteLine("- 4 : Comprobar pedidos pendientes -");
            Console.WriteLine("------------------------------------");
        }

        public static int ObtainOption()
        {
            int option;

            while (!Int32.TryParse(Console.ReadLine(), out option) || option < 0 || option > 4)
                Console.WriteLine("Error: Valor no valido");

            return option;
        }

        public static void ShowOrder(Order order)
        {
            decimal totalPrice = 0;
            int index = 1;

            order.GetProducts().ForEach(product => Console.WriteLine($"{index++}.- {product.ToString()}"));
            Console.WriteLine("Fecha: {0}", order.GetDateTime());
            order.GetProducts().ForEach(product => totalPrice += product.GetPrice());
            Console.WriteLine("Coste total: {0} euros", totalPrice);
        }

        public static void ShowOrders(List<Order> orders)
        {
            for (int i = 0; i < orders.Count; i++)
            {
                Console.WriteLine("Pedido nº {0}", i + 1);
                ShowOrder(orders[i]);
            }
        }

        public static void ShowProducts(List<Product> products)
        {
            int index = 1;
            products.ForEach(product => Console.WriteLine($"{index++}.- {product.ToString()}"));
        }
    }
}
