﻿using System;

namespace Cafeteria
{
    class Program
    {
        public static void Main(string[] args)
        {
            const string FILE = "Products.txt";
            CoffeShop coffeShop = new CoffeShop(Product.ObtainProducts(FILE));
            int option;

            if (coffeShop.GetProducts().Count != 0)
            {
                do
                {
                    Console.Clear();
                    Menu.ShowMenu();
                    switch (option = Menu.ObtainOption())
                    {
                        case 1:
                            if (coffeShop.GetUncompletedOrders().Count < 5)
                                coffeShop.GetUncompletedOrders().Add(Order.MakeOrder(coffeShop.GetProducts()));
                            else
                                Console.WriteLine("Hay demasiados pedidos pendientes,completa una primero");
                            break;
                        case 2:
                            if (coffeShop.GetUncompletedOrders().Count > 0)
                            {
                                Menu.ShowOrder(coffeShop.GetUncompletedOrders()[0]);
                                coffeShop.CompleteOrder();
                                Console.WriteLine("La comanda se ha completado con exito");
                            }
                            else
                                Console.WriteLine("No hay pedidos pendientes");
                            break;
                        case 3:
                            if (coffeShop.GetUncompletedOrders().Count >= 0)
                                CoffeShop.RecordMoney(coffeShop.GetCompletedOrdes());
                            else
                                Console.WriteLine("Aun hay pedidos pendientes");
                            break;
                        case 4:
                            if (coffeShop.GetUncompletedOrders().Count != 0)
                                Menu.ShowOrders(coffeShop.GetUncompletedOrders());
                            else
                                Console.WriteLine("No hay pedidos pendientes");
                            break;
                    }
                    Console.ReadKey();
                } while (option != 0);
                Console.WriteLine("Finalizaste el programa...");
            }
        }
    }
}