﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    class Product
    {
        private string Name { get; set; }
        private decimal Price { get; set; }

        internal Order Order
        {
            get => default;
            set
            {
            }
        }

        public Product(string name, decimal price)
        {
            SetName(name);
            SetPrice(price);
        }

        public void SetName(string name) 
        {
            if (!String.IsNullOrEmpty(name))
                Name = name;
            else
                Name = "Error";
        }
        public string GetName() { return Name; }

        public void SetPrice(decimal price) 
        {
            if (price > 0)
                Price = price;
            else
                Price = 0;
        }
        public decimal GetPrice() { return Price; }

        public override string ToString() { return ($"{Name} Precio: {Price} euros"); }

        public static List<Product> ObtainProducts(string filePath)
        {
            List<Product> products = new List<Product>();
            StreamReader SR;
            string line;

            if (File.Exists("..\\..\\..\\" + filePath))
            {
                try
                {
                    SR = new StreamReader("..\\..\\..\\" + filePath);
                    while (!SR.EndOfStream)
                    {
                        line = SR.ReadLine();
                        products.Add(new Product(line.Split(';')[0], Convert.ToDecimal(line.Split(';')[1])));
                    }
                    SR.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error de lectura del fichero \"{0}\" ", filePath);
                    products.Clear();
                }
            }
            else
                Console.WriteLine("Error: fichero \"{0}\" no localizado", filePath);

            return products;
        }
    }
}
