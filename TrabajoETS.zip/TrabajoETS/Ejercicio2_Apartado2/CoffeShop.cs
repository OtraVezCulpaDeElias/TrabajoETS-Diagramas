﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria
{
    class CoffeShop
    {
        private List<Product> Products { get; set; }
        private List<Order> UncompletedOrders { get; set; }
        private List<Order> CompletedOrdes { get; set; }

        private const int UncompletedOrdersLimit = 5;

        public CoffeShop(List<Product> products)
        {
            SetProducts(products);
            this.UncompletedOrders = new List<Order>();
            this.CompletedOrdes = new List<Order>();
        }

        public void SetProducts(List<Product> products) { Products = products; }
        public List<Product> GetProducts() { return Products; }

        public void SetUncompletedOrders(List<Order> orders) { UncompletedOrders = orders; }
        public List<Order> GetUncompletedOrders() { return UncompletedOrders; }

        public void SetCompletedOrdes(List<Order> orders) { CompletedOrdes = orders; }
        public List<Order> GetCompletedOrdes() { return CompletedOrdes; }

        public void CompleteOrder()
        {
            CompletedOrdes.Add(UncompletedOrders[0]);
            UncompletedOrders.RemoveAt(0);
        }

        public static void RecordMoney(List<Order> orders)
        {
            decimal moneyMade = 0;
            Menu.ShowOrders(orders);
            foreach (Order order in orders)
            {
                order.GetProducts().ForEach(product => moneyMade += product.GetPrice());
            }
            Console.WriteLine("Caja total hasta el momento : {0}", moneyMade);
        }
    }
}
