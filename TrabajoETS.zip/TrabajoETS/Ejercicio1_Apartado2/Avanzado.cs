﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado2
{
    public class Avanzado : Jugador
    {
        private bool conduciendo
        {
            get => default;
            set
            {
            }
        }

        public void Conducir()
        {
            throw new System.NotImplementedException();
        }

        public bool SetConduciendo()
        {
            throw new System.NotImplementedException();
        }

        public bool GetConduciendo()
        {
            throw new System.NotImplementedException();
        }
    }
}