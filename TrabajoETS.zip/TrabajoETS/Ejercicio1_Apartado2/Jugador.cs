﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio1_Apartado2
{
    public class Jugador
    {
        private string nombre
        {
            get => default;
            set
            {
            }
        }

        private int numeroVidas
        {
            get => default;
            set
            {
            }
        }

        private decimal coordenadasX
        {
            get => default;
            set
            {
            }
        }

        private decimal coordenadaY
        {
            get => default;
            set
            {
            }
        }
    }
}