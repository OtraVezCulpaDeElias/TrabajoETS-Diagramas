﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio2_Apartado3
{
    public class Figura
    {
        private string color
        {
            get => default;
            set
            {
            }
        }

        public void CalcularArea()
        {
            throw new System.NotImplementedException();
        }

        public void MostrarAreaCalculada()
        {
            throw new System.NotImplementedException();
        }
    }
}