﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio2_Apartado3
{
    public class Triangulo : Figura
    {
        private decimal @base
        {
            get => default;
            set
            {
            }
        }

        private decimal altura
        {
            get => default;
            set
            {
            }
        }
    }
}