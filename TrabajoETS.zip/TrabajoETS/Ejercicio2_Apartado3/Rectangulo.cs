﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio2_Apartado3
{
    public class Rectangulo : Figura
    {
        private decimal ancho
        {
            get => default;
            set
            {
            }
        }

        private decimal largo
        {
            get => default;
            set
            {
            }
        }
    }
}