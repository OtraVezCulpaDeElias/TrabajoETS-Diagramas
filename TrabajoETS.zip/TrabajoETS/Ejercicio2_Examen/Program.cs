﻿using System;

namespace ExamenObjetos
{
    class Program
    {
        public static void Main(string[] args)
        {
            Tienda tienda = new Tienda("Ivan", 922000001);
            tienda.GetJuegos().Add(new Juego("Zelda", 35.70m));
            tienda.GetJuegos().Add(new Juego("Mario", 30m));
            tienda.GetJuegos().Add(new Juego("Sonic", 27.40m));
            tienda.GetJuegos().Add(new Juego("Final Fantasy XX", 45.90m));
            tienda.GetJuegos().Add(new Juego("Pokemon", 50.45m));
            List<Cliente> clientes = new List<Cliente>();
            clientes.Add(new Cliente("Pepe", 111));
            clientes.Add(new Cliente("Pepa", 222));
            clientes.Add(new Cliente("Pipo", 333));
            clientes.Add(new Cliente("Pope", 444));
            clientes.Add(new Cliente("Papu", 555));
            clientes.Add(new Cliente("Pepu", 666));
            int opcion;

            if (!tienda.GetNombre().Equals("Error"))
            {
                do
                {
                    Console.Clear();
                    Menú.MostrarMenu();
                    switch (opcion = Menú.PedirOpción())
                    {
                        case 0: Console.WriteLine("Finalizaste el programa"); break;
                        case 1: Tienda.AlquilarJuego(tienda,clientes); break;
                        case 2: Tienda.DevolverJuego(tienda); break;
                        case 3: Console.WriteLine(tienda.ToString()); break;
                        case 4: Tienda.MirarHistorial(tienda); break;
                    }
                    Console.ReadKey();
                } while (opcion != 0);
            }
            else
            {
                Console.WriteLine("hola");
            }

        }
    }
}