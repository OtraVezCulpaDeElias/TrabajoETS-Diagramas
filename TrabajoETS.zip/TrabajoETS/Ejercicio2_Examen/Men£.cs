﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenObjetos
{
    class Menú
    {
        public static void MostrarMenu()
        {
            Console.WriteLine("--------------------------");
            Console.WriteLine("- Elija una opción:      -");
            Console.WriteLine("--------------------------");
            Console.WriteLine("- 0: Salir               -");
            Console.WriteLine("- 1: Alquilar Juego      -");
            Console.WriteLine("- 2: Devolver Juego      -");
            Console.WriteLine("- 3: Mostrar info tienda -");
            Console.WriteLine("- 4: Mostrar historial   -");
            Console.WriteLine("--------------------------");
        }

        public static int PedirOpción()
        {
            int opcion;

            while(!Int32.TryParse(Console.ReadLine(),out opcion) || opcion<0 || opcion > 4)
            {
                Console.WriteLine("Opción incorrecta");
            }

            return opcion;
        }
    }
}
