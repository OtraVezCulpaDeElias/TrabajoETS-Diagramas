﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenObjetos
{
    class Alquiler
    {
        private Juego JuegoAlquilado { get; set; }
        private int CodigoCliente { get; set; }

        internal Tienda Tienda
        {
            get => default;
            set
            {
            }
        }

        public Alquiler(Juego juegoAlquilado, int codigoCliente)
        {
            JuegoAlquilado = juegoAlquilado;
            CodigoCliente = codigoCliente;
        }

        public override string ToString()
        {
            return $"{JuegoAlquilado.ToString()} --Usuario que lo tiene: {CodigoCliente}";
        }

        public Juego GetJuego() { return JuegoAlquilado; }
        public int GetCodigoCliente() { return CodigoCliente; }

    }
}
