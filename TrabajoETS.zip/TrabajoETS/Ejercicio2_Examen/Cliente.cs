﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenObjetos
{
    class Cliente
    {
        private string Nombre { get; set; }
        private int Codigo { get; set; }

        internal Alquiler Alquiler
        {
            get => default;
            set
            {
            }
        }

        public Cliente() { }
        public Cliente(string nombre, int codigo)
        {
            SetNombre(nombre);
            SetCodigo(codigo);
        }

        public void SetNombre(string nombre)
        {
            if (!String.IsNullOrEmpty(nombre))
                Nombre = nombre;
            else
                Nombre = "Error";
        }
        public string GetNombre() { return Nombre; }

        public void SetCodigo(int codigo)
        {
            if (codigo > 100 && codigo < 999)
                Codigo = codigo;
            else
                codigo = -1;
        }
        public int GetCodigo() { return Codigo; }
    }
}
