﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ExamenObjetos
{
    class Tienda
    {
        private string Encargado { get; set; }
        private int Telefono { get; set; }
        private List<Juego> Juegos { get; set; }
        private List<Alquiler> JuegosAlquilados { get; set; }

        public Tienda() { }
        public Tienda(string encargado, int telefono)
        {
            SetEncargado(encargado);
            SeTelefono(telefono);
            Juegos = new List<Juego>();
            JuegosAlquilados = new List<Alquiler>();
        }

        public void SetEncargado(string encargado)
        {
            if (!String.IsNullOrEmpty(encargado) && encargado.Length >= 3)
                Encargado = encargado;
            else
                Encargado = "Error";
        }
        public string GetNombre() { return Encargado; }

        public void SeTelefono(int telefono)
        {
            if (telefono > 922000000 || telefono < 922999999)
                Telefono = telefono;
            else
                Telefono = -1;
        }
        public int GetTelefono() { return Telefono; }

        public void SetJuegos(List<Juego> juegos) { Juegos = juegos; }
        public List<Juego> GetJuegos() { return Juegos; }

        public static string PedirEncargado()
        {
            string encargado;

            Console.WriteLine("Como se llama el encargado de esta tiena?");
            while (String.IsNullOrEmpty(encargado = Console.ReadLine()) || encargado.Length < 3)
                Console.WriteLine("Formato incorrecto");

            return encargado;
        }
        public static int PedirTelefono()
        {
            int telefono;

            Console.WriteLine("Cual es el telefono de esta tiena?");
            while (!Int32.TryParse(Console.ReadLine(), out telefono) || telefono < 922000000 || telefono > 922999999)
                Console.WriteLine("Formato incorrecto");
            
            return telefono;
        }

        public static void AlquilarJuego(Tienda tienda,List<Cliente> clientes)
        {
            int index = 1;
            int codigo;
            int opcion;
            bool clienteEncontrado = false;
            int contador = 0;

            Console.WriteLine("Cual es el cliente que va a alquilar el juego?");
            while (!Int32.TryParse(Console.ReadLine(), out codigo) || codigo < 100 || codigo > 999)
                Console.WriteLine("Formato incorrecto");
            while (!clienteEncontrado || contador != clientes.Count)
            {
                if (clientes[contador].GetCodigo() == codigo)
                {
                    clienteEncontrado = true;
                    Console.WriteLine("Elija un juego:");
                    tienda.Juegos.ForEach(juego => Console.WriteLine($"{index++}.- {juego.ToString()}"));

                    while (!Int32.TryParse(Console.ReadLine(), out opcion) || opcion < 1 || opcion > tienda.Juegos.Count)
                        Console.WriteLine("Opcion no existente");
                    tienda.JuegosAlquilados.Add(new Alquiler(tienda.Juegos[opcion-1],codigo));
                    tienda.Juegos[contador].GetHistorial().Add(codigo);
                    tienda.Juegos.RemoveAt(opcion-1);
                }
                contador++;
            }
            if (!clienteEncontrado)
                Console.WriteLine("Ese cliente no existe");
            else
                Console.WriteLine("Alquiler realizado con exito");
        }

        public static void DevolverJuego(Tienda tienda)
        {
            int codigo;
            int contador = 0;
            bool clienteEncontrado = false;

            Console.WriteLine("Cual es el cliente que va a devolver el juego?");
            while (!Int32.TryParse(Console.ReadLine(), out codigo) || codigo < 100 || codigo > 999)
                Console.WriteLine("Formato incorrecto");

            while (!clienteEncontrado && contador != tienda.JuegosAlquilados.Count)
            {
                if (tienda.JuegosAlquilados[contador].GetCodigoCliente() == codigo)
                {
                    clienteEncontrado = true;
                    tienda.Juegos.Add(tienda.JuegosAlquilados[contador].GetJuego());
                    tienda.JuegosAlquilados.RemoveAt(contador);
                }
                contador++;
            }
            if (!clienteEncontrado)
            {
                Console.WriteLine("no se encuentra el cliente o no tiene un juego alquilado");
            }
            else
            {
                Console.WriteLine("devolucion realizada con exito");
            }
        }

        public static void MirarHistorial(Tienda tienda)
        {
            int index = 1;
            int opcion;

            Console.WriteLine("Elija un juego:");
            tienda.Juegos.ForEach(juego => Console.WriteLine($"{index++}.- {juego.ToString()}"));

            while (!Int32.TryParse(Console.ReadLine(), out opcion) || opcion < 1 || opcion > tienda.Juegos.Count)
                Console.WriteLine("Opcion no existente");

            foreach(int codigo in tienda.Juegos[opcion-1].GetHistorial())
                Console.WriteLine(codigo);
        }

        public override string ToString()
        {
            string cadena="";

            cadena += $"Nombre del propietario: {Encargado}\n";
            cadena += $"Numero de telefono de la tienda: {Telefono}\n";
            cadena += $"Juegos disponibles: \n\n";

            Juegos.ForEach(juego=> cadena+= $"{juego.ToString()}\n");

            cadena += $"\nJuegos alquilados: \n\n";

            JuegosAlquilados.ForEach(juego => cadena += $"{juego.ToString()}\n");

            return cadena;
        }
    }
}
