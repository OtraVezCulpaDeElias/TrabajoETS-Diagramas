﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenObjetos
{
    class Juego
    {
        private string Nombre { get; set; }
        private decimal Precio { get; set; }
        /// <summary>
        /// Lista con los codigos de las personas que han alquilado el juego
        /// </summary>
        private List<int> Historial { get; set; }

        internal Tienda Tienda
        {
            get => default;
            set
            {
            }
        }

        public Juego() { }
        public Juego(string nombre, decimal precio)
        {
            SetNombre(nombre);
            SetPrecio(precio);
            Historial = new List<int>();
        }

        public void SetNombre(string nombre)
        {
            if (!String.IsNullOrEmpty(nombre))
                Nombre = nombre;
            else
                Nombre = "Error";
        }
        public string GetNombre() { return Nombre; }

        public void SetPrecio(decimal precio)
        {
            if (precio > 0)
                Precio = precio;
            else
                precio = -1;
        }
        public decimal GetPrecio() { return Precio; }

        public void SetHistorial(List<int> historial) { Historial = historial; }
        public List<int> GetHistorial() { return Historial; }
        public override string ToString() { return $"Nombre: {Nombre} - Precio: {Precio}"; }
    }
}
