﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio2_Apartado1
{
    public class Linea
    {
        private Producto producto
        {
            get => default;
            set
            {
            }
        }

        private int stock
        {
            get => default;
            set
            {
            }
        }

        public Maquina Maquina
        {
            get => default;
            set
            {
            }
        }

        public override string ToString()
        {
            return base.ToString();
        }

    }
}