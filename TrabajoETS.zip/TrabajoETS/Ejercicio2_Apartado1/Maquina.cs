﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio2_Apartado1
{
    public class Maquina
    {
        private int maximoLineas
        {
            get => default;
            set
            {
            }
        }

        private int stockMax
        {
            get => default;
            set
            {
            }
        }

        private System.Collections.Generic.List<Linea> lineas
        {
            get => default;
            set
            {
            }
        }

        private string nombre
        {
            get => default;
            set
            {
            }
        }

        public string ToString()
        {
            throw new System.NotImplementedException();
        }

        public decimal PedirDinero()
        {
            throw new System.NotImplementedException();
        }

        public void AñadirLinea(Producto producto)
        {
            throw new System.NotImplementedException();
        }

        public Linea BorrarLinea(int posicion)
        {
            throw new System.NotImplementedException();
        }

        public bool EstaLleno()
        {
            throw new System.NotImplementedException();
        }
    }
}