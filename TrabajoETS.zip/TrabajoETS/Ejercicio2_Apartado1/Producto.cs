﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio2_Apartado1
{
    public class Producto
    {
        private string nombre
        {
            get => default;
            set
            {
            }
        }

        private decimal precio
        {
            get => default;
            set
            {
            }
        }

        public Linea Linea
        {
            get => default;
            set
            {
            }
        }

        public string ToString()
        {
            throw new System.NotImplementedException();
        }

        public static string PedirNombre()
        {
            throw new System.NotImplementedException();
        }

        public static decimal PedirPrecio()
        {
            throw new System.NotImplementedException();
        }
    }
}